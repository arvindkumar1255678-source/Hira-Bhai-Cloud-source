"use strict";

const crypto = require("node:crypto");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");

const DB_PATH = path.join(__dirname, "data", "hira-cloud.db");
const db = new DatabaseSync(DB_PATH);

db.exec(`
  PRAGMA foreign_keys = ON;
  PRAGMA busy_timeout = 5000;
  PRAGMA trusted_schema = OFF;
`);

const SCRYPT_OPTIONS = {
  N: 32768,
  r: 8,
  p: 1,
  maxmem: 64 * 1024 * 1024
};

const KEY_LENGTH = 64;
const SESSION_DAYS = 30;

function makePasswordHash(password) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(
    password,
    salt,
    KEY_LENGTH,
    SCRYPT_OPTIONS
  );

  return [
    "scrypt",
    SCRYPT_OPTIONS.N,
    SCRYPT_OPTIONS.r,
    SCRYPT_OPTIONS.p,
    salt.toString("hex"),
    key.toString("hex")
  ].join("$");
}

function checkPassword(password, storedHash) {
  try {
    const parts = storedHash.split("$");

    if (parts.length !== 6 || parts[0] !== "scrypt") {
      return false;
    }

    const N = Number(parts[1]);
    const r = Number(parts[2]);
    const p = Number(parts[3]);
    const salt = Buffer.from(parts[4], "hex");
    const expected = Buffer.from(parts[5], "hex");

    if (
      !Number.isSafeInteger(N) || N !== 32768 ||
      !Number.isSafeInteger(r) || r !== 8 ||
      !Number.isSafeInteger(p) || p !== 1 ||
      salt.length !== 16 ||
      expected.length !== KEY_LENGTH
    ) {
      return false;
    }

    const actual = crypto.scryptSync(
      password,
      salt,
      KEY_LENGTH,
      SCRYPT_OPTIONS
    );

    return crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

function publicUser(user) {
  if (!user) return null;

  return {
    id: user.id,
    email: user.email,
    username: user.username,
    displayName: user.display_name,
    role: user.role,
    status: user.status,
    createdAt: user.created_at
  };
}

function validateRegistration(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new Error("INVALID_INPUT");
  }

  const email = String(input.email || "").trim().toLowerCase();

  const usernameValue =
    input.username == null ? "" : String(input.username).trim();

  const username = usernameValue
    ? usernameValue.toLowerCase()
    : null;

  const displayName =
    input.displayName == null
      ? ""
      : String(input.displayName).trim();

  const password = input.password;

  if (
    email.length > 254 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  ) {
    throw new Error("INVALID_EMAIL");
  }

  if (username !== null && !/^[a-z0-9_]{3,24}$/.test(username)) {
    throw new Error("INVALID_USERNAME");
  }

  if (
    typeof password !== "string" ||
    Buffer.byteLength(password, "utf8") < 12 ||
    Buffer.byteLength(password, "utf8") > 1024
  ) {
    throw new Error("PASSWORD_POLICY");
  }

  if (displayName.length > 80) {
    throw new Error("INVALID_DISPLAY_NAME");
  }

  return { email, username, displayName, password };
}

function registerUser(input) {
  const data = validateRegistration(input);
  const id = crypto.randomUUID();
  const passwordHash = makePasswordHash(data.password);

  db.exec("BEGIN IMMEDIATE");

  try {
    db.prepare(`
      INSERT INTO users (
        id, email, username, display_name,
        password_hash, role, status
      )
      VALUES (?, ?, ?, ?, ?, 'user', 'active')
    `).run(
      id,
      data.email,
      data.username,
      data.displayName || null,
      passwordHash
    );

    const session = createSession(id);

    const user = db.prepare(
      "SELECT * FROM users WHERE id = ?"
    ).get(id);

    db.exec("COMMIT");

    return {
      user: publicUser(user),
      token: session.token,
      expiresAt: session.expiresAt
    };
  } catch (error) {
    try {
      db.exec("ROLLBACK");
    } catch {}

    if (
      String(error.code || "").includes("CONSTRAINT") ||
      String(error.message || "").toLowerCase().includes("constraint")
    ) {
      throw new Error("ACCOUNT_ALREADY_EXISTS");
    }

    throw error;
  }
}

function createSession(userId) {
  const token = crypto.randomBytes(32).toString("base64url");
  const tokenHash = crypto.createHash("sha256")
    .update(token)
    .digest("hex");

  const sessionId = crypto.randomUUID();
  const expiresAt = new Date(
    Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000
  ).toISOString();

  db.prepare(`
    INSERT INTO auth_sessions (
      id, user_id, token_hash, expires_at
    )
    VALUES (?, ?, ?, ?)
  `).run(sessionId, userId, tokenHash, expiresAt);

  return {
    token,
    expiresAt
  };
}

function loginUser(email, password) {
  if (
    typeof email !== "string" ||
    typeof password !== "string" ||
    Buffer.byteLength(password, "utf8") > 1024
  ) {
    throw new Error("INVALID_CREDENTIALS");
  }

  const normalizedEmail = email.trim().toLowerCase();

  const user = db.prepare(`
    SELECT * FROM users
    WHERE email = ?
  `).get(normalizedEmail);

  if (!user || !user.password_hash) {
    throw new Error("INVALID_CREDENTIALS");
  }

  if (!checkPassword(password, user.password_hash)) {
    throw new Error("INVALID_CREDENTIALS");
  }

  if (user.status !== "active") {
    throw new Error("ACCOUNT_NOT_ACTIVE");
  }

  const session = createSession(user.id);

  return {
    user: publicUser(user),
    token: session.token,
    expiresAt: session.expiresAt
  };
}

function verifySession(token) {
  if (
    typeof token !== "string" ||
    !/^[A-Za-z0-9_-]{43}$/.test(token)
  ) {
    return null;
  }

  const tokenHash = crypto.createHash("sha256")
    .update(token)
    .digest("hex");

  const session = db.prepare(`
    SELECT
      s.id AS session_id,
      s.expires_at,
      s.revoked_at,
      u.*
    FROM auth_sessions s
    JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ?
  `).get(tokenHash);

  if (
    !session ||
    session.revoked_at ||
    new Date(session.expires_at).getTime() <= Date.now() ||
    session.status !== "active"
  ) {
    return null;
  }

  return publicUser(session);
}

function logoutUser(token) {
  if (
    typeof token !== "string" ||
    !/^[A-Za-z0-9_-]{43}$/.test(token)
  ) {
    return false;
  }

  const tokenHash = crypto.createHash("sha256")
    .update(token)
    .digest("hex");

  const result = db.prepare(`
    UPDATE auth_sessions
    SET revoked_at = datetime('now')
    WHERE token_hash = ? AND revoked_at IS NULL
  `).run(tokenHash);

  return Number(result.changes) > 0;
}

function close() {
  db.close();
}

module.exports = {
  registerUser,
  loginUser,
  verifySession,
  logoutUser,
  close
};
