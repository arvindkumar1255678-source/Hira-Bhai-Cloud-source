const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const Busboy = require("busboy");
const { isMp4File } = require("./mp4-check");
const monitoring = require("./monitoring/monitor");
require("./cloud-database");
const auth = require("./cloud-auth");
const videoStore = require("./video-store");

const ROOT =
  path.join(process.env.HOME, "storage/shared/HiraBhai/Published");

const PORT = 8787;
const SERVER_STARTED_AT = Date.now();
const TOKEN_PATH = require("path").join(__dirname, ".admin_token");
const ADMIN_TOKEN = fs.readFileSync(TOKEN_PATH, "utf8").trim();

function isAdmin(req) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return false;
  const supplied = Buffer.from(token);
  const expected = Buffer.from(ADMIN_TOKEN);
  if (supplied.length === expected.length &&
      crypto.timingSafeEqual(supplied, expected)) return true;
  const user = auth.verifySession(token);
  return !!user && user.role === "admin";
}


const mime = {
  ".mp4": "video/mp4",
  ".m3u8": "application/vnd.apple.mpegurl",
  ".ts": "video/mp2t",
  ".jpg": "image/jpeg",
  ".png": "image/png"
};


const authRateLimits = new Map();

function checkAuthRateLimit(key, limit, windowMs) {
  const now = Date.now();
  let record = authRateLimits.get(key);

  if (!record || now >= record.resetAt) {
    record = { count: 0, resetAt: now + windowMs };
    authRateLimits.set(key, record);
  }

  if (record.count >= limit) {
    return {
      allowed: false,
      retryAfter: Math.max(1, Math.ceil((record.resetAt - now) / 1000))
    };
  }

  record.count++;

  if (authRateLimits.size > 5000) {
    for (const [storedKey, storedRecord] of authRateLimits) {
      if (now >= storedRecord.resetAt) authRateLimits.delete(storedKey);
    }
  }

  return { allowed: true, retryAfter: 0 };
}

async function readAuthJson(req) {
  const contentType = req.headers["content-type"] || "";

  if (!/^application\/json\b/i.test(contentType)) {
    throw new Error("JSON_REQUIRED");
  }

  const declaredLength = Number(req.headers["content-length"] || 0);
  if (declaredLength > 16384) throw new Error("BODY_TOO_LARGE");

  const chunks = [];
  let total = 0;

  for await (const chunk of req) {
    total += chunk.length;
    if (total > 16384) throw new Error("BODY_TOO_LARGE");
    chunks.push(chunk);
  }

  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new Error("INVALID_JSON");
  }
}

function sendAuthJson(res, status, data, extraHeaders = {}) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...extraHeaders
  });
  res.end(JSON.stringify(data));
}

function getBearerToken(req) {
  const header = req.headers.authorization || "";
  if (!header.startsWith("Bearer ")) return null;

  const token = header.slice(7);
  return /^[A-Za-z0-9_-]{43}$/.test(token) ? token : null;
}

const server = http.createServer(async (req, res) => {
  monitoring.recordRequest(req, res);
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("X-Content-Type-Options", "nosniff");

  const url = new URL(req.url, "http://localhost");

  if (req.method === "OPTIONS" &&
      url.pathname.startsWith("/api/auth/")) {
    res.writeHead(204, {
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Max-Age": "600"
    });
    return res.end();
  }

  if (req.method === "POST" &&
      (url.pathname === "/api/auth/register" ||
       url.pathname === "/api/auth/login")) {
    const isRegister = url.pathname === "/api/auth/register";
    const ip = req.socket.remoteAddress || "unknown";
    const action = isRegister ? "register" : "login";

    const limit = checkAuthRateLimit(
      action + ":" + ip,
      isRegister ? 5 : 10,
      15 * 60 * 1000
    );

    if (!limit.allowed) {
      return sendAuthJson(
        res,
        429,
        { error: "Too many attempts. Please try again later." },
        { "Retry-After": String(limit.retryAfter) }
      );
    }

    let input;
    try {
      input = await readAuthJson(req);
    } catch (error) {
      const status =
        error.message === "BODY_TOO_LARGE" ? 413 :
        error.message === "JSON_REQUIRED" ? 415 : 400;

      return sendAuthJson(status === 0 ? res : res, status, {
        error:
          status === 413 ? "Request body too large" :
          status === 415 ? "Use application/json" :
          "Invalid JSON request"
      });
    }

    try {
      if (isRegister) {
        const result = auth.registerUser(input);
        return sendAuthJson(res, 201, {
          status: "registered",
          user: result.user,
          token: result.token,
          expiresAt: result.expiresAt
        });
      }

      const result = auth.loginUser(input.email, input.password);
      return sendAuthJson(res, 200, {
        status: "authenticated",
        user: result.user,
        token: result.token,
        expiresAt: result.expiresAt
      });
    } catch (error) {
      const messages = {
        INVALID_INPUT: [400, "Invalid registration data"],
        INVALID_EMAIL: [400, "Invalid email address"],
        INVALID_USERNAME: [400, "Invalid username"],
        PASSWORD_POLICY: [400, "Password does not meet security requirements"],
        INVALID_DISPLAY_NAME: [400, "Invalid display name"],
        ACCOUNT_ALREADY_EXISTS: [409, "Email or username already exists"],
        INVALID_CREDENTIALS: [401, "Invalid email or password"],
        ACCOUNT_NOT_ACTIVE: [403, "Account is not active"]
      };

      const response = messages[error.message] || [500, "Authentication service error"];

      if (response[0] === 500) {
        console.error("Authentication request failed:", error.message);
      }

      return sendAuthJson(res, response[0], { error: response[1] });
    }
  }

  if (req.method === "GET" && url.pathname === "/api/auth/me") {
    const token = getBearerToken(req);
    const user = token ? auth.verifySession(token) : null;

    if (!user) {
      return sendAuthJson(res, 401, {
        error: "Authentication required"
      });
    }

    return sendAuthJson(res, 200, { user });
  }

  if (req.method === "POST" && url.pathname === "/api/auth/logout") {
    const token = getBearerToken(req);

    if (!token || !auth.verifySession(token)) {
      return sendAuthJson(res, 401, {
        error: "Invalid or expired session"
      });
    }

    auth.logoutUser(token);
    return sendAuthJson(res, 200, { status: "logged_out" });
  }

  if (req.method === "POST" && url.pathname === "/admin/upload") {
    if (!isAdmin(req)) {
      res.writeHead(401, {"Content-Type":"application/json"});
      return res.end(JSON.stringify({error:"Unauthorized"}));
    }
    if (!/^multipart\/form-data\b/i.test(req.headers["content-type"] || "")) {
      res.writeHead(400);
      return res.end(JSON.stringify({error:"Use multipart/form-data"}));
    }
    let parser;
    try {
      parser=Busboy({headers:req.headers,limits:{
        files:1,fileSize:2*1024*1024*1024,fields:12,fieldSize:20000
      }});
    } catch {
      res.writeHead(400);
      return res.end(JSON.stringify({error:"Invalid upload"}));
    }
    const fields={};
    let fileSeen=false,uploadName=null,filePath=null,uploadError=null;
    let writePromise=Promise.resolve();
    parser.on("field",(name,value)=>{fields[name]=value;});
    parser.on("file",(field,file,info)=>{
      fileSeen=true;
      if(field!=="video"||!info.filename||
         path.extname(info.filename).toLowerCase()!==".mp4"){
        uploadError="Only MP4 video files are accepted";
        file.resume(); return;
      }
      uploadName="video-"+Date.now()+"-"+crypto.randomBytes(8).toString("hex")+".mp4";
      filePath=path.join(ROOT,uploadName);
      const output=fs.createWriteStream(filePath,{flags:"wx"});
      file.on("limit",()=>{uploadError="Video exceeds the 2 GB limit";});
      writePromise=new Promise(resolve=>{
        output.on("error",()=>{uploadError="Storage write failed";resolve();});
        output.on("finish",resolve);
        file.on("error",()=>{uploadError="Upload stream failed";output.destroy();resolve();});
        file.pipe(output);
      });
    });
    parser.on("filesLimit",()=>{uploadError="Only one video is allowed";});
    parser.on("fieldsLimit",()=>{uploadError="Too many metadata fields";});
    parser.on("error",()=>{uploadError="Upload request failed";});
    parser.on("finish",async()=>{
      await writePromise;
      if(!uploadError&&filePath){
        try { if(!isMp4File(filePath)) uploadError="Invalid MP4 file"; }
        catch { uploadError="Could not verify MP4 file"; }
      }
      let savedToDatabase=false;
      if(!uploadError&&fileSeen&&uploadName&&Object.keys(fields).length){
        const token=getBearerToken(req);
        const user=token?auth.verifySession(token):null;
        if(!user||user.role!=="admin"||user.status!=="active"){
          uploadError="Active Cloud Admin session required for video metadata";
        } else {
          try {
            const title=(fields.title||"").trim();
            const creatorId=(fields.creatorId||"").trim();
            const visibility=fields.visibility||"public";
            const hashtags=fields.hashtags?JSON.parse(fields.hashtags):[];
            const durationMs=Number(fields.durationMs||0);
            const aspectRatio=fields.aspectRatio?Number(fields.aspectRatio):null;
            if(!title||title.length>240||!creatorId||
               !["public","private","unlisted"].includes(visibility)||
               !Array.isArray(hashtags)||hashtags.length>50||
               !Number.isFinite(durationMs)||durationMs<0||
               (aspectRatio!==null&&(!Number.isFinite(aspectRatio)||aspectRatio<=0))){
              throw new Error("Invalid video metadata");
            }
            videoStore.insertVideo({
              video_id:crypto.randomUUID(),
              owner_user_id:user.id,
              legacy_owner_uid:fields.legacyOwnerUid||null,
              creator_id:creatorId,
              creator_username:fields.creatorUsername||"",
              creator_name:fields.creatorName||"",
              title,description:(fields.description||"").slice(0,10000),
              visibility,storage_path:uploadName,
              duration_ms:Math.floor(durationMs),
              is_short:["true","1","yes"].includes((fields.isShort||"").toLowerCase()),
              hashtags,aspect_ratio:aspectRatio
            });
            savedToDatabase=true;
          } catch(error) {
            uploadError=error.message||"Database save failed";
          }
        }
      }
      if(uploadError||!fileSeen||!uploadName){
        if(filePath) await fs.promises.unlink(filePath).catch(()=>{});
        if(!res.headersSent){
          res.writeHead(uploadError==="Invalid video metadata"?400:500,{"Content-Type":"application/json"});
          res.end(JSON.stringify({error:uploadError||"No video received"}));
        }
        return;
      }
      res.writeHead(201,{"Content-Type":"application/json"});
      res.end(JSON.stringify({status:"uploaded",filename:uploadName,database:savedToDatabase?"saved":"legacy"}));
    });
    req.pipe(parser);
    return;
  }

  if (req.method === "GET" && url.pathname === "/admin/monitoring") {
    const token = getBearerToken(req);
    const user = token ? auth.verifySession(token) : null;
    if (!user || user.role !== "admin" || user.status !== "active") {
      res.writeHead(403, {"Content-Type": "application/json", "Cache-Control": "no-store"});
      return res.end(JSON.stringify({error: "Admin access required"}));
    }
    try {
      const snapshot = monitoring.getSnapshot(ROOT, SERVER_STARTED_AT);
      res.writeHead(200, {"Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store"});
      return res.end(JSON.stringify(snapshot));
    } catch {
      res.writeHead(503, {"Content-Type": "application/json", "Cache-Control": "no-store"});
      return res.end(JSON.stringify({error: "Monitoring temporarily unavailable"}));
    }
  }

  if (req.method === "GET" && url.pathname === "/admin/check") {
    if (!isAdmin(req)) {
      res.writeHead(401, {"Content-Type": "application/json"});
      return res.end(JSON.stringify({error: "Unauthorized"}));
    }
    res.writeHead(200, {"Content-Type": "application/json"});
    return res.end(JSON.stringify({status: "authorized"}));
  }

  if (req.method === "GET" && url.pathname === "/health") {
    res.writeHead(200, {
      "Content-Type": "application/json"
    });
    return res.end(JSON.stringify({
      status: "online",
      platform: "Hira Bhai Cloud"
    }));
  }

  if (req.method === "GET" && url.pathname === "/api/videos") {
    try {
      const stored = videoStore.listPublicVideos();
      const known = new Set(stored.map(v => path.basename(v.storage_path)));
      const files = await fs.promises.readdir(ROOT);
      const legacy = [];
      for (const name of files) {
        if (!/\\.(mp4|m3u8)$/i.test(name) || known.has(name)) continue;
        const stat = await fs.promises.stat(path.join(ROOT, name));
        if (!stat.isFile()) continue;
        legacy.push({
          id: Buffer.from(name).toString("base64url"),
          title: path.parse(name).name,
          format: path.extname(name).slice(1),
          size: stat.size,
          streamUrl: "/media/" + encodeURIComponent(name),
          legacy: true
        });
      }
      const videos = stored.map(v => ({
        id: v.video_id, title: v.title, description: v.description,
        creatorId: v.creator_id, creatorUsername: v.creator_username,
        creatorName: v.creator_name, format: "mp4",
        durationMs: v.duration_ms, isShort: !!v.is_short,
        hashtags: v.hashtags, thumbnailUrl: v.thumbnailUrl,
        streamUrl: v.streamUrl, createdAt: v.created_at
      })).concat(legacy);
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({
        platform:"Hira Bhai Cloud", total:videos.length, videos
      }));
    } catch (error) {
      console.error("Video listing failed:", error.message);
      res.writeHead(500, {"Content-Type":"application/json"});
      return res.end(JSON.stringify({error:"Video listing unavailable"}));
    }
  }

  if (req.method === "GET" &&
      url.pathname.startsWith("/media/")) {

    let name;

    try {
      name = decodeURIComponent(
        url.pathname.slice("/media/".length)
      );
    } catch {
      res.writeHead(400);
      return res.end("Invalid filename");
    }

    if (!name || path.basename(name) !== name ||
        name.startsWith(".")) {
      res.writeHead(400);
      return res.end("Invalid filename");
    }

    const file = path.join(ROOT, name);

    try {
      const stat = await fs.promises.stat(file);

      if (!stat.isFile()) throw new Error("Not a file");

      const type =
        mime[path.extname(name).toLowerCase()] ||
        "application/octet-stream";

      res.setHeader("Content-Type", type);
      res.setHeader("Accept-Ranges", "bytes");

      const range = req.headers.range;

      if (range) {
        const match = /^bytes=(\d*)-(\d*)$/.exec(range);

        if (!match) {
          res.writeHead(416);
          return res.end();
        }

        let start = match[1] ? Number(match[1]) : 0;
        let end = match[2] ? Number(match[2]) : stat.size - 1;

        if (!Number.isSafeInteger(start) ||
            !Number.isSafeInteger(end) ||
            start >= stat.size || end < start) {
          res.writeHead(416);
          return res.end();
        }

        end = Math.min(end, stat.size - 1);

        res.writeHead(206, {
          "Content-Length": end - start + 1,
          "Content-Range":
            `bytes ${start}-${end}/${stat.size}`
        });

        return fs.createReadStream(file, {
          start, end
        }).pipe(res);
      }

      res.writeHead(200, {
        "Content-Length": stat.size
      });

      return fs.createReadStream(file).pipe(res);

    } catch {
      res.writeHead(404);
      return res.end("Video not found");
    }
  }

  res.writeHead(404);
  res.end("Not found");
});

server.listen(PORT, "127.0.0.1", () => {
  console.log("HIRA BHAI CLOUD SERVER ONLINE");
  console.log("Port:", PORT);
  console.log("Storage:", ROOT);
});
