  if (req.method === "POST" && url.pathname === "/admin/upload") {
    if (!isAdmin(req)) {
      res.writeHead(401, {"Content-Type": "application/json"});
      return res.end(JSON.stringify({error: "Unauthorized"}));
    }

    if (!/^multipart\/form-data\b/i.test(req.headers["content-type"] || "")) {
      res.writeHead(400, {"Content-Type": "application/json"});
      return res.end(JSON.stringify({error: "Use multipart/form-data"}));
    }

    let parser;
    try {
      parser = Busboy({
        headers: req.headers,
        limits: {files: 1, fileSize: 2 * 1024 * 1024 * 1024, fields: 0}
      });
    } catch {
      res.writeHead(400);
      return res.end("Invalid upload");
    }

    let fileSeen = false;
    let uploadName = null;
    let filePath = null;
    let uploadError = null;
    let writePromise = Promise.resolve();

    parser.on("file", (field, file, info) => {
      fileSeen = true;

      if (field !== "video" || !info.filename ||
          path.extname(info.filename).toLowerCase() !== ".mp4") {
        uploadError = "Only MP4 video files are accepted";
        file.resume();
        return;
      }

      uploadName = "video-" + Date.now() + "-" +
        crypto.randomBytes(8).toString("hex") + ".mp4";
      filePath = path.join(ROOT, uploadName);

      const output = fs.createWriteStream(filePath, {flags: "wx"});

      file.on("limit", () => {
        uploadError = "Video exceeds the 2 GB limit";
      });

      writePromise = new Promise((resolve) => {
        output.on("error", () => {
          uploadError = "Storage write failed";
          resolve();
        });
        output.on("finish", resolve);
        file.on("error", () => {
          uploadError = "Upload stream failed";
          output.destroy();
          resolve();
        });
        file.pipe(output);
      });
    });

    parser.on("filesLimit", () => {
      uploadError = "Only one video is allowed";
    });

    parser.on("error", () => {
      uploadError = "Upload request failed";
    });

    parser.on("finish", async () => {
      await writePromise;

      if (uploadError || !fileSeen || !uploadName) {
        if (filePath) await fs.promises.unlink(filePath).catch(() => {});
        if (!res.headersSent) {
          res.writeHead(400, {"Content-Type": "application/json"});
          res.end(JSON.stringify({error: uploadError || "No video received"}));
        }
        return;
      }

      res.writeHead(201, {"Content-Type": "application/json"});
      res.end(JSON.stringify({
        status: "uploaded",
        filename: uploadName
      }));
    });

    req.pipe(parser);
    return;
  }
