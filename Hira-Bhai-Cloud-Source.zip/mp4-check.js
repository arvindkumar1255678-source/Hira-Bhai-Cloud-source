function isMp4File(filePath) {
  const fd = require("fs").openSync(filePath, "r");
  try {
    const header = Buffer.alloc(12);
    const bytesRead = require("fs").readSync(fd, header, 0, 12, 0);
    return bytesRead === 12 &&
      header.toString("ascii", 4, 8) === "ftyp";
  } finally {
    require("fs").closeSync(fd);
  }
}

module.exports = { isMp4File };
