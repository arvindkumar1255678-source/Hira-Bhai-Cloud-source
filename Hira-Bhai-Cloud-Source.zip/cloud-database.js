"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");

const DATA_DIR = path.join(__dirname, "data");
const DB_PATH = path.join(DATA_DIR, "hira-cloud.db");

fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
fs.chmodSync(DATA_DIR, 0o700);

const db = new DatabaseSync(DB_PATH);

try {
  db.exec(`
    PRAGMA foreign_keys = ON;
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = FULL;
    PRAGMA busy_timeout = 5000;
    PRAGMA trusted_schema = OFF;

    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      description TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      firebase_uid TEXT UNIQUE,
      email TEXT COLLATE NOCASE UNIQUE,
      username TEXT COLLATE NOCASE UNIQUE,
      display_name TEXT,
      password_hash TEXT,
      role TEXT NOT NULL DEFAULT 'user'
        CHECK (role IN ('user', 'admin')),
      status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'suspended', 'pending')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS auth_sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      revoked_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_sessions_user
      ON auth_sessions(user_id);

    CREATE INDEX IF NOT EXISTS idx_sessions_expiry
      ON auth_sessions(expires_at);

    CREATE TABLE IF NOT EXISTS user_files (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL,
      legacy_owner_uid TEXT,
      name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 240),
      mime_type TEXT NOT NULL CHECK (length(mime_type) <= 160),
      size_bytes INTEGER NOT NULL
        CHECK (size_bytes BETWEEN 0 AND 104857600),
      storage_path TEXT NOT NULL UNIQUE
        CHECK (length(storage_path) <= 600),
      visibility TEXT NOT NULL DEFAULT 'private'
        CHECK (visibility IN ('private', 'public')),
      folder TEXT NOT NULL DEFAULT '' CHECK (length(folder) <= 80),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_files_owner
      ON user_files(owner_user_id);

    CREATE INDEX IF NOT EXISTS idx_files_visibility
      ON user_files(visibility);

    CREATE TABLE IF NOT EXISTS user_file_shares (
      file_id TEXT NOT NULL,
      shared_with_user_id TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (file_id, shared_with_user_id),
      FOREIGN KEY (file_id) REFERENCES user_files(id) ON DELETE CASCADE,
      FOREIGN KEY (shared_with_user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_file_shares_user
      ON user_file_shares(shared_with_user_id);
  `);

  db.prepare(`
    INSERT OR IGNORE INTO schema_migrations (version, description)
    VALUES (?, ?)
  `).run(1, "Initial Hira Bhai Cloud database schema");

  const currentVersion = db.prepare(
    "SELECT MAX(version) AS version FROM schema_migrations"
  ).get().version || 0;

  if (currentVersion < 2) {
    db.exec("BEGIN IMMEDIATE");

    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS username_claims (
          username TEXT PRIMARY KEY COLLATE NOCASE
            CHECK (
              length(username) BETWEEN 3 AND 24
              AND username = lower(username)
              AND username NOT GLOB '*[^a-z0-9_]*'
            ),
          user_id TEXT NOT NULL UNIQUE,
          creator_id TEXT NOT NULL UNIQUE,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS creator_profiles (
          user_id TEXT PRIMARY KEY,
          creator_id TEXT NOT NULL UNIQUE,
          username TEXT NOT NULL UNIQUE,
          full_name TEXT NOT NULL
            CHECK (length(full_name) BETWEEN 2 AND 80),
          bio TEXT NOT NULL DEFAULT ''
            CHECK (length(bio) <= 500),
          website_url TEXT NOT NULL DEFAULT ''
            CHECK (length(website_url) <= 2048),
          photo_data TEXT,
          updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (username) REFERENCES username_claims(username)
        );

        CREATE TABLE IF NOT EXISTS public_profiles (
          username TEXT PRIMARY KEY COLLATE NOCASE,
          user_id TEXT NOT NULL UNIQUE,
          creator_id TEXT NOT NULL UNIQUE,
          full_name TEXT NOT NULL,
          search_name TEXT NOT NULL,
          bio TEXT NOT NULL DEFAULT '',
          website_url TEXT NOT NULL DEFAULT '',
          photo_data TEXT,
          updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (username) REFERENCES username_claims(username)
            ON DELETE CASCADE,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_public_profiles_search
          ON public_profiles(search_name);

        CREATE INDEX IF NOT EXISTS idx_public_profiles_creator
          ON public_profiles(creator_id);

        CREATE TABLE IF NOT EXISTS user_directory (
          username TEXT PRIMARY KEY COLLATE NOCASE,
          user_id TEXT NOT NULL UNIQUE,
          creator_id TEXT NOT NULL UNIQUE,
          display_name TEXT NOT NULL,
          search_name TEXT NOT NULL,
          updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (username) REFERENCES username_claims(username)
            ON DELETE CASCADE,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_user_directory_search
          ON user_directory(search_name);

        CREATE TABLE IF NOT EXISTS user_settings (
          user_id TEXT PRIMARY KEY,
          notifications_enabled INTEGER NOT NULL DEFAULT 1
            CHECK (notifications_enabled IN (0, 1)),
          notification_previews INTEGER NOT NULL DEFAULT 1
            CHECK (notification_previews IN (0, 1)),
          playback_speed REAL NOT NULL DEFAULT 1.0
            CHECK (playback_speed IN (0.5, 0.75, 1.0, 1.25, 1.5, 2.0)),
          recommendations_enabled INTEGER NOT NULL DEFAULT 1
            CHECK (recommendations_enabled IN (0, 1)),
          updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
      `);

      db.prepare(`
        INSERT INTO schema_migrations (version, description)
        VALUES (?, ?)
      `).run(2, "Creator profiles, username directory and user settings");

      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  }

  const versionBeforeVideos = db.prepare(
    "SELECT MAX(version) AS version FROM schema_migrations"
  ).get().version || 0;

  if (versionBeforeVideos < 3) {
    db.exec("BEGIN IMMEDIATE");
    try {
      db.exec(`
        CREATE TABLE IF NOT EXISTS videos (
          video_id TEXT PRIMARY KEY,
          owner_user_id TEXT NOT NULL,
          legacy_owner_uid TEXT,
          creator_id TEXT NOT NULL,
          creator_username TEXT NOT NULL DEFAULT '',
          creator_name TEXT NOT NULL DEFAULT '',
          title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 240),
          description TEXT NOT NULL DEFAULT '',
          visibility TEXT NOT NULL DEFAULT 'public'
            CHECK (visibility IN ('public','private','unlisted')),
          storage_path TEXT NOT NULL UNIQUE,
          thumbnail_storage_path TEXT,
          caption_storage_path TEXT,
          duration_ms INTEGER NOT NULL DEFAULT 0 CHECK (duration_ms >= 0),
          is_short INTEGER NOT NULL DEFAULT 0 CHECK (is_short IN (0,1)),
          hashtags_json TEXT NOT NULL DEFAULT '[]',
          aspect_ratio REAL,
          status TEXT NOT NULL DEFAULT 'ready'
            CHECK (status IN ('processing','ready','failed')),
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (owner_user_id) REFERENCES users(id)
        );
        CREATE INDEX IF NOT EXISTS idx_videos_owner
          ON videos(owner_user_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_videos_visibility
          ON videos(visibility, status, created_at);
        CREATE INDEX IF NOT EXISTS idx_videos_creator
          ON videos(creator_id, created_at);
      `);
      db.prepare(
        "INSERT INTO schema_migrations (version, description) VALUES (?, ?)"
      ).run(3, "Videos, thumbnails and captions metadata");
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  }

  const finalVersion = db.prepare(
    "SELECT MAX(version) AS version FROM schema_migrations"
  ).get().version;

  const tables = db.prepare(`
    SELECT COUNT(*) AS count
    FROM sqlite_master
    WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
  `).get().count;

  console.log("HIRA BHAI CLOUD DATABASE: READY");
  console.log("Database: data/hira-cloud.db");
  console.log("Schema version:", finalVersion);
  console.log("Tables:", tables);
} finally {
  db.close();
}

fs.chmodSync(DB_PATH, 0o600);

for (const suffix of ["-wal", "-shm"]) {
  const file = DB_PATH + suffix;
  if (fs.existsSync(file)) fs.chmodSync(file, 0o600);
}

console.log("Database file permissions: 600");
console.log("Private data directory permissions: 700");
