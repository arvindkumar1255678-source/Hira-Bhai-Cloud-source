#!/data/data/com.termux/files/usr/bin/bash

PROJECT="$HOME/hira-cloud"
SERVER="$PROJECT/server.js"
PIDFILE="$PROJECT/server-auth-api.pid"
LOGFILE="$PROJECT/server-auth-api.log"
PORT_URL="http://127.0.0.1:8787/health"

find_project_pids() {
    for f in /proc/[0-9]*/cmdline; do
        [ -r "$f" ] || continue
        pid="${f#/proc/}"
        pid="${pid%/cmdline}"
        cmd="$(tr '\0' ' ' < "$f" 2>/dev/null)"
        cwd="$(readlink "/proc/$pid/cwd" 2>/dev/null)"

        if [ "$cwd" = "$PROJECT" ]; then
            case "$cmd" in
                "node server.js "*|"${PREFIX}/bin/node server.js "*)
                    echo "$pid"
                    ;;
            esac
        fi
    done
}

health_check() {
    curl -sS -o /dev/null --max-time 2 \
        -w '%{http_code}' "$PORT_URL" 2>/dev/null
}

case "${1:-status}" in
    status)
        PIDS="$(find_project_pids)"
        if [ -n "$PIDS" ]; then
            echo "SERVER ONLINE"
            echo "Project PID(s): $PIDS"
            echo "Health HTTP: $(health_check)"
        else
            echo "PROJECT PROCESS NOT FOUND"
            CODE="$(health_check)"
            if [ "$CODE" = "200" ]; then
                echo "WARNING: Port 8787 responds, but project process was not identified."
            else
                echo "SERVER OFFLINE"
            fi
        fi
        ;;

    start)
        [ -f "$SERVER" ] || {
            echo "ERROR: server.js not found."
            exit 1
        }

        PIDS="$(find_project_pids)"
        if [ -n "$PIDS" ]; then
            echo "Server already running. PID(s): $PIDS"
            exit 0
        fi

        CODE="$(health_check)"
        if [ "$CODE" = "200" ]; then
            echo "ERROR: Port 8787 responds, but project process is not identified."
            echo "Not starting another server."
            exit 1
        fi

        cd "$PROJECT" || exit 1
        nohup node server.js >> "$LOGFILE" 2>&1 < /dev/null &
        NEWPID=$!
        echo "$NEWPID" > "$PIDFILE"

        for i in $(seq 1 10); do
            sleep 1
            PIDS="$(find_project_pids)"
            if [ -n "$PIDS" ] && [ "$(health_check)" = "200" ]; then
                echo "SERVER ONLINE"
                echo "Project PID(s): $PIDS"
                exit 0
            fi
        done

        echo "ERROR: Server did not become healthy."
        echo "Recent log:"
        tail -30 "$LOGFILE"
        exit 1
        ;;

    stop)
        PIDS="$(find_project_pids)"
        if [ -z "$PIDS" ]; then
            echo "Project server process not found. Nothing stopped."
            exit 0
        fi

        for pid in $PIDS; do
            echo "Stopping project PID: $pid"
            kill -TERM "$pid" 2>/dev/null || true
        done

        for i in $(seq 1 5); do
            sleep 1
            REMAINING="$(find_project_pids)"
            [ -z "$REMAINING" ] && break
        done

        REMAINING="$(find_project_pids)"
        if [ -z "$REMAINING" ]; then
            echo "PROJECT SERVER STOPPED"
        else
            echo "WARNING: Process still running: $REMAINING"
            echo "No force-kill was attempted."
            exit 1
        fi
        ;;

    *)
        echo "Usage: $0 {start|stop|status}"
        exit 2
        ;;
esac
