"use strict";
const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
const DB_PATH = path.join(__dirname, "..", "data", "hira-cloud.db");

const activity = {
  total: 0, success: 0, clientErrors: 0, serverErrors: 0,
  uploads: 0, streams: 0, streamedBytes: 0,
  routes: Object.create(null), errors: []
};

function recordRequest(req, res) {
  const method = req.method || "UNKNOWN";
  const route = (req.url || "/").split("?")[0].replace(/\/[0-9a-f-]{20,}/gi, "/:id");
  const key = method + " " + route;
  activity.total++;
  activity.routes[key] = (activity.routes[key] || 0) + 1;
  const upload = method === "POST" && route === "/admin/upload";
  const stream = method === "GET" && route.startsWith("/media/");
  if (upload) activity.uploads++;
  if (stream) activity.streams++;
  res.once("finish", () => {
    const status = res.statusCode || 0;
    if (status >= 200 && status < 400) activity.success++;
    else if (status >= 400 && status < 500) activity.clientErrors++;
    else if (status >= 500) {
      activity.serverErrors++;
      activity.errors.push({
        time: new Date().toISOString(),
        method, route, status
      });
      if (activity.errors.length > 30) activity.errors.shift();
    }
    if (stream) {
      const size = Number(res.getHeader("Content-Length") || 0);
      if (Number.isFinite(size)) activity.streamedBytes += size;
    }
  });
}

function getSnapshot(root, startedAt) {
  const db = new DatabaseSync(DB_PATH, { readOnly: true });
  try {
    const users = db.prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status='active' THEN 1 ELSE 0 END) AS active, SUM(CASE WHEN status='suspended' THEN 1 ELSE 0 END) AS suspended FROM users").get();
    const sessions = db.prepare("SELECT COUNT(*) AS total FROM auth_sessions WHERE revoked_at IS NULL AND expires_at > datetime('now')").get();
    const storage = { files: 0, usedBytes: 0, totalBytes: null, freeBytes: null };
    if (fs.existsSync(root)) {
      for (const name of fs.readdirSync(root)) {
        try {
          const stat = fs.statSync(path.join(root, name));
          if (stat.isFile() && /\.(mp4|m3u8|ts)$/i.test(name)) {
            storage.files++;
            storage.usedBytes += stat.size;
          }
        } catch {}
      }
      try {
        const disk = fs.statfsSync(root);
        storage.totalBytes = disk.blocks * disk.bsize;
        storage.freeBytes = disk.bavail * disk.bsize;
      } catch {}
    }
    return {
      platform: "Hira Bhai Cloud",
      timestamp: new Date().toISOString(),
      uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000),
      memory: process.memoryUsage(),
      users: {
        total: Number(users.total || 0),
        active: Number(users.active || 0),
        suspended: Number(users.suspended || 0)
      },
      activeSessions: Number(sessions.total || 0),
      storage,
      activity: {
        total: activity.total,
        success: activity.success,
        clientErrors: activity.clientErrors,
        serverErrors: activity.serverErrors,
        uploads: activity.uploads,
        streams: activity.streams,
        streamedBytes: activity.streamedBytes,
        topRoutes: Object.entries(activity.routes).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([route,count])=>({route,count})),
        recentErrors: activity.errors.slice(-10)
      },
      database: "read-only"
    };
  } finally { db.close(); }
}
module.exports = { getSnapshot, recordRequest };
