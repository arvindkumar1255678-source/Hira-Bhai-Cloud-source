"use strict";
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
const db = new DatabaseSync(path.join(__dirname,"data","hira-cloud.db"));
function listPublicVideos() {
  return db.prepare(`
    SELECT video_id, owner_user_id, creator_id, creator_username,
      creator_name, title, description, visibility, storage_path,
      thumbnail_storage_path, duration_ms, is_short, hashtags_json,
      aspect_ratio, created_at
    FROM videos
    WHERE visibility='public' AND status='ready'
    ORDER BY created_at DESC
  `).all().map(v => ({
    ...v,
    hashtags: JSON.parse(v.hashtags_json || "[]"),
    streamUrl: "/media/" + encodeURIComponent(path.basename(v.storage_path)),
    thumbnailUrl: v.thumbnail_storage_path
      ? "/media/" + encodeURIComponent(path.basename(v.thumbnail_storage_path))
      : null
  }));
}
function insertVideo(v) {
  db.prepare(`
    INSERT INTO videos (
      video_id, owner_user_id, legacy_owner_uid, creator_id,
      creator_username, creator_name, title, description, visibility,
      storage_path, thumbnail_storage_path, duration_ms, is_short,
      hashtags_json, aspect_ratio, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ready')
  `).run(
    v.video_id, v.owner_user_id, v.legacy_owner_uid || null,
    v.creator_id, v.creator_username || "", v.creator_name || "",
    v.title, v.description || "", v.visibility, v.storage_path,
    v.thumbnail_storage_path || null, v.duration_ms || 0,
    v.is_short ? 1 : 0, JSON.stringify(v.hashtags || []),
    v.aspect_ratio || null
  );
}
module.exports = { listPublicVideos, insertVideo };
