"use strict";

const crypto = require("node:crypto");
const readline = require("node:readline");
const { DatabaseSync } = require("node:sqlite");
const path = require("node:path");

const DB_PATH = path.join(__dirname, "data", "hira-cloud.db");

const SCRYPT_OPTIONS = {
  N: 32768,
  r: 8,
  p: 1,
  maxmem: 64 * 1024 * 1024
};

const KEY_LENGTH = 64;

function askVisible(question) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  return new Promise(resolve => {
    rl.question(question, answer => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

function askHidden(question) {
  return new Promise((resolve, reject) => {
    const input = process.stdin;

    if (!input.isTTY || typeof input.setRawMode !== "function") {
      reject(new Error("इस Terminal में सुरक्षित password input उपलब्ध नहीं है।"));
      return;
    }

    let value = "";
    let finished = false;

    process.stdout.write(question);
    input.setRawMode(true);
    input.resume();
    input.setEncoding("utf8");

    function cleanup() {
      if (finished) return;
      finished = true;
      input.removeListener("data", onData);
      input.setRawMode(false);
      process.stdout.write("\n");
    }

    function onData(chunk) {
      for (const char of chunk) {
        if (char === "\u0003") {
          cleanup();
          reject(new Error("रिकवरी रद्द की गई।"));
          return;
        }

        if (char === "\r" || char === "\n") {
          cleanup();
          resolve(value);
          return;
        }

        if (char === "\u007f" || char === "\b") {
          value = Array.from(value).slice(0, -1).join("");
          continue;
        }

        if (char >= " " && char !== "\u007f") {
          value += char;
        }
      }
    }

    input.on("data", onData);
  });
}

function makePasswordHash(password) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(
    password,
    salt,
    KEY_LENGTH,
    SCRYPT_OPTIONS
  );

  return [
    "scrypt",
    SCRYPT_OPTIONS.N,
    SCRYPT_OPTIONS.r,
    SCRYPT_OPTIONS.p,
    salt.toString("hex"),
    key.toString("hex")
  ].join("$");
}

async function main() {
  console.log("HIRA BHAI CLOUD — LOCAL ACCOUNT RECOVERY");
  console.log("पासवर्ड इस Terminal से बाहर नहीं भेजा जाएगा।");
  console.log("");

  const email = await askVisible("रजिस्ट्रेशन वाला Email दर्ज करें: ");
  const normalizedEmail = email.toLowerCase();

  if (
    normalizedEmail.length > 254 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)
  ) {
    throw new Error("Email का प्रारूप सही नहीं है।");
  }

  const password1 = await askHidden("नया पासवर्ड दर्ज करें (छिपा रहेगा): ");
  const password2 = await askHidden("नया पासवर्ड दोबारा दर्ज करें: ");

  const bytes = Buffer.byteLength(password1, "utf8");

  if (bytes < 12 || bytes > 1024) {
    throw new Error("पासवर्ड 12 से 1024 bytes के बीच होना चाहिए।");
  }

  if (password1 !== password2) {
    throw new Error("दोनों पासवर्ड मेल नहीं खाते।");
  }

  const confirmation = await askVisible(
    "मौजूदा अकाउंट का पासवर्ड बदलने के लिए RESET लिखें: "
  );

  if (confirmation !== "RESET") {
    throw new Error("पुष्टि नहीं मिली। कोई बदलाव नहीं किया गया।");
  }

  const passwordHash = makePasswordHash(password1);

  let db;
  try {
    db = new DatabaseSync(DB_PATH);

    db.exec(`
      PRAGMA foreign_keys = ON;
      PRAGMA busy_timeout = 10000;
      PRAGMA trusted_schema = OFF;
      BEGIN IMMEDIATE;
    `);

    const user = db.prepare(`
      SELECT id
      FROM users
      WHERE email = ? COLLATE NOCASE
      LIMIT 1
    `).get(normalizedEmail);

    if (!user) {
      throw new Error("इस Email से कोई अकाउंट नहीं मिला।");
    }

    const result = db.prepare(`
      UPDATE users
      SET password_hash = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).run(passwordHash, user.id);

    if (Number(result.changes) !== 1) {
      throw new Error("अकाउंट अपडेट नहीं हुआ।");
    }

    db.prepare(`
      UPDATE auth_sessions
      SET revoked_at = datetime('now')
      WHERE user_id = ?
        AND revoked_at IS NULL
    `).run(user.id);

    db.exec("COMMIT");

    console.log("");
    console.log("सफलता: मौजूदा अकाउंट का पासवर्ड बदल दिया गया है।");
    console.log("अकाउंट की पहचान और बाकी जानकारी सुरक्षित रखी गई है।");
    console.log("अब ऐप में नए पासवर्ड से Login करें।");
  } catch (error) {
    if (db) {
      try { db.exec("ROLLBACK"); } catch {}
    }
    throw error;
  } finally {
    if (db) db.close();
  }
}

main().catch(error => {
  console.error("\nरिकवरी पूरी नहीं हुई:", error.message);
  process.exitCode = 1;
});
