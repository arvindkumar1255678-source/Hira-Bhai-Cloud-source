"use strict";
const {DatabaseSync}=require("node:sqlite");
const db=new DatabaseSync("data/hira-cloud.db");
db.exec(`
PRAGMA foreign_keys=ON;
PRAGMA journal_mode=WAL;
PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS cloud_records(
 collection TEXT NOT NULL,
 record_id TEXT NOT NULL,
 owner_user_id TEXT NOT NULL,
 visibility TEXT NOT NULL DEFAULT 'private'
 CHECK(visibility IN ('private','public')),
 data_json TEXT NOT NULL CHECK(json_valid(data_json)),
 created_at TEXT NOT NULL DEFAULT(datetime('now')),
 updated_at TEXT NOT NULL DEFAULT(datetime('now')),
 PRIMARY KEY(collection,record_id)
);
CREATE INDEX IF NOT EXISTS idx_cloud_owner
ON cloud_records(owner_user_id,collection);
CREATE INDEX IF NOT EXISTS idx_cloud_public
ON cloud_records(collection,visibility);
CREATE TABLE IF NOT EXISTS cloud_activity(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id TEXT,
 action TEXT NOT NULL,
 resource TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'success',
 created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_activity_time
ON cloud_activity(created_at);
CREATE INDEX IF NOT EXISTS idx_activity_user
ON cloud_activity(user_id,created_at);
`);
const allowed=new Set([
"aiAppProjects","aiConversations","assistantTasks","audios",
"blockedUsers","captions","chat","comments","communityPosts",
"creatorEarnings","creatorPayouts","creatorStats",
"creatorWebsiteProjects","creatorWebsites","creators",
"favoriteAudio","items","likes","liveStreams","messages","movies",
"notifications","payouts","playlists","profiles","projects",
"publicPlaylists","publicProfiles","recommendationPreferences",
"subscriptionTestStats","subscriptionTests","subscriptions",
"threads","transactions","userActivity","userDirectory",
"userFiles","userPlaylists","userSettings","usernames",
"videoStats","videos","watchHistory","watchLater"
]);
function check(c,id,owner){
 if(!allowed.has(c)||typeof id!=="string"||!id||id.length>180||
 typeof owner!=="string"||!owner) throw Error("INVALID_RECORD");
}
function put(c,id,owner,data,visibility="private"){
 check(c,id,owner);
 if(!["private","public"].includes(visibility)) throw Error("INVALID_VISIBILITY");
 const json=JSON.stringify(data);
 if(!json||Buffer.byteLength(json)>1048576) throw Error("RECORD_TOO_LARGE");
 db.prepare(`INSERT INTO cloud_records
 (collection,record_id,owner_user_id,visibility,data_json)
 VALUES(?,?,?,?,?)
 ON CONFLICT(collection,record_id) DO UPDATE SET
 data_json=excluded.data_json,visibility=excluded.visibility,
 updated_at=datetime('now')
 WHERE cloud_records.owner_user_id=excluded.owner_user_id`)
 .run(c,id,owner,visibility,json);
 return get(c,id,owner);
}
function get(c,id,owner){
 check(c,id,owner);
 const r=db.prepare(`SELECT record_id,visibility,data_json,created_at,updated_at
 FROM cloud_records WHERE collection=? AND record_id=? AND
 (owner_user_id=? OR visibility='public')`).get(c,id,owner);
 return r?{id:r.record_id,visibility:r.visibility,data:JSON.parse(r.data_json),
 createdAt:r.created_at,updatedAt:r.updated_at}:null;
}
function list(c,owner,limit=50){
 if(!allowed.has(c)||typeof owner!=="string"||!owner) throw Error("INVALID_QUERY");
 limit=Math.max(1,Math.min(100,Number(limit)||50));
 return db.prepare(`SELECT record_id,visibility,data_json,created_at,updated_at
 FROM cloud_records WHERE collection=? AND
 (owner_user_id=? OR visibility='public')
 ORDER BY updated_at DESC LIMIT ?`).all(c,owner,limit)
 .map(r=>({id:r.record_id,visibility:r.visibility,data:JSON.parse(r.data_json),
 createdAt:r.created_at,updatedAt:r.updated_at}));
}
function remove(c,id,owner){
 check(c,id,owner);
 return db.prepare(`DELETE FROM cloud_records
 WHERE collection=? AND record_id=? AND owner_user_id=?`).run(c,id,owner).changes>0;
}
function log(user,action,resource,status="success"){
 db.prepare(`INSERT INTO cloud_activity(user_id,action,resource,status)
 VALUES(?,?,?,?)`).run(user||null,String(action).slice(0,80),
 String(resource).slice(0,160),String(status).slice(0,30));
}
function stats(){
 return {
 records:db.prepare("SELECT COUNT(*) n FROM cloud_records").get().n,
 users:db.prepare("SELECT COUNT(*) n FROM users").get().n,
 activity:db.prepare("SELECT COUNT(*) n FROM cloud_activity").get().n
 };
}
module.exports={put,get,list,remove,log,stats,allowed};
