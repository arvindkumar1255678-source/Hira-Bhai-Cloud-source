#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

BASE="$HOME/hira-cloud"
APP="$BASE/app-source/Hira Bhai"
LAUNCHER="$APP/HiraBhai-GitHub/launcher"
CONTROL="$BASE/cloud-control-app"
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT="$BASE/releases/$STAMP"
BACKUP="$BASE/backups/master-update-$STAMP"

mkdir -p "$OUT" "$BACKUP"

echo "======================================"
echo " HIRA BHAI MASTER UPDATE"
echo "======================================"

projects=("$APP" "$LAUNCHER" "$CONTROL")
names=("Main-App" "OS-Launcher" "Cloud-Control")

for i in "${!projects[@]}"; do
  P="${projects[$i]}"
  N="${names[$i]}"

  if [ ! -d "$P" ] || [ ! -f "$P/build.gradle" ] && [ ! -f "$P/build.gradle.kts" ]; then
    echo "ERROR: $N Gradle project not found: $P"
    exit 1
  fi

  echo "BACKUP: $N"
  tar -czf "$BACKUP/$N-source.tar.gz" \
    --exclude='build' --exclude='.gradle' \
    -C "$(dirname "$P")" "$(basename "$P")"

  echo "BUILD: $N"
  gradle -p "$P" assembleDebug --no-daemon --console=plain

  APK="$(find "$P" -type f -path '*/build/outputs/apk/debug/*.apk' \
    ! -name '*-androidTest*' | head -n 1)"

  if [ -z "$APK" ] || [ ! -s "$APK" ]; then
    echo "ERROR: $N APK build output missing"
    exit 1
  fi

  cp "$APK" "$OUT/$N.apk"
  echo "SUCCESS: $N"
done

{
  echo "HIRA BHAI MASTER UPDATE"
  echo "Date: $STAMP"
  echo "APK files:"
  ls -lh "$OUT"/*.apk
  echo "Backups: $BACKUP"
} | tee "$OUT/REPORT.txt"

echo "======================================"
echo "MASTER BUILD COMPLETED"
echo "OUTPUT: $OUT"
echo "BACKUP: $BACKUP"
echo "======================================"
