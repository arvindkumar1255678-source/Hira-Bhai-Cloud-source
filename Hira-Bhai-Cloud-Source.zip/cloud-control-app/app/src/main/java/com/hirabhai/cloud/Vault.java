package com.hirabhai.cloud;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class Vault {
    private static final String STORE = "hira_cloud_secure_vault";
    private static final String KEY_ALIAS = "hira_bhai_cloud_auth_key";
    private static final String TOKEN_KEY = "cloud_auth_token";
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private static final Object LOCK = new Object();

    private static volatile Context appContext;

    private Vault() {}

    public static void initialize(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("Context is required");
        }
        appContext = context.getApplicationContext();
    }

    private static SharedPreferences preferences() {
        Context context = appContext;
        if (context == null) {
            throw new IllegalStateException("Vault is not initialized");
        }
        return context.getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null);

        if (keyStore.containsAlias(KEY_ALIAS)) {
            KeyStore.SecretKeyEntry entry =
                    (KeyStore.SecretKeyEntry) keyStore.getEntry(KEY_ALIAS, null);
            return entry.getSecretKey();
        }

        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);

        generator.init(new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build());

        return generator.generateKey();
    }

    public static void putToken(String token) throws Exception {
        if (token == null || !token.matches("[A-Za-z0-9_-]{43}")) {
            throw new IllegalArgumentException("Invalid authentication token");
        }

        synchronized (LOCK) {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());

            byte[] encrypted = cipher.doFinal(
                    token.getBytes(StandardCharsets.UTF_8));
            byte[] iv = cipher.getIV();

            ByteBuffer buffer = ByteBuffer.allocate(iv.length + encrypted.length);
            buffer.put(iv);
            buffer.put(encrypted);

            String encoded = Base64.encodeToString(
                    buffer.array(), Base64.NO_WRAP);

            if (!preferences().edit()
                    .putString(TOKEN_KEY, encoded)
                    .commit()) {
                throw new IllegalStateException("Could not save secure token");
            }
        }
    }

    public static String getToken() {
        synchronized (LOCK) {
            try {
                String encoded = preferences().getString(TOKEN_KEY, null);
                if (encoded == null) return null;

                byte[] data = Base64.decode(encoded, Base64.NO_WRAP);
                if (data.length <= 12) return null;

                byte[] iv = new byte[12];
                byte[] encrypted = new byte[data.length - 12];

                System.arraycopy(data, 0, iv, 0, 12);
                System.arraycopy(data, 12, encrypted, 0, encrypted.length);

                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(),
                        new GCMParameterSpec(128, iv));

                String token = new String(
                        cipher.doFinal(encrypted), StandardCharsets.UTF_8);

                return token.matches("[A-Za-z0-9_-]{43}") ? token : null;
            } catch (Exception e) {
                return null;
            }
        }
    }

    public static void clearToken() {
        synchronized (LOCK) {
            preferences().edit().remove(TOKEN_KEY).commit();
        }
    }
}
