package com.hirabhai.cloud;

import org.json.JSONObject;
import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.text.InputType;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private LinearLayout root;
    private TextView serverStatus;
    private Button refreshButton;
    private TextView loginServerStatus;
    private boolean serverCommandInProgress = false;

    private final int BG = Color.rgb(7, 20, 38);
    private final int CYAN = Color.rgb(56, 217, 245);
    private final int GREEN = Color.rgb(53, 224, 161);
    private final int WHITE = Color.rgb(243, 248, 255);
    private final int MUTED = Color.rgb(168, 185, 204);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Vault.initialize(getApplicationContext());
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        showAuthScreen(false, "Checking saved session...");

        new Thread(() -> {
            try {
                CloudAuthClient.User user = CloudAuthClient.verifySession();

                runOnUiThread(() -> {
                    if (user != null) {
                        buildDashboard();
                        checkServer();
                    } else {
                        showAuthScreen(false, "Please sign in to continue.");
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() ->
                    showAuthScreen(false,
                        "Could not verify session. Please sign in again.")
                );
            }
        }).start();
    }


    private EditText authEmail;
    private EditText authPassword;
    private EditText authUsername;
    private EditText authDisplayName;
    private TextView authStatus;
    private Button authButton;

    private EditText createAuthInput(String hint, int inputType) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setTextSize(15);
        field.setTextColor(WHITE);
        field.setHintTextColor(MUTED);
        field.setHint(hint);
        field.setInputType(inputType);
        field.setPadding(dp(15), dp(10), dp(15), dp(10));
        field.setBackground(glassBackground(
            Color.rgb(20, 43, 66), 0x665B8AA5
        ));
        return field;
    }

    private void addAuthField(LinearLayout layout, EditText field) {
        LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(-1, dp(54));
        params.topMargin = dp(12);
        layout.addView(field, params);
    }

    private void showAuthScreen(boolean registerMode, String message) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout layout = vertical();
        layout.setPadding(dp(24), dp(35), dp(24), dp(30));
        scroll.addView(layout);
        setContentView(scroll);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.hira_bhai_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("Hira Bhai Logo");

        LinearLayout.LayoutParams logoParams =
            new LinearLayout.LayoutParams(dp(82), dp(82));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        layout.addView(logo, logoParams);

        TextView brand = text("HIRA BHAI CLOUD", 19, CYAN, true);
        brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brandParams =
            new LinearLayout.LayoutParams(-1, dp(42));
        layout.addView(brand, brandParams);

        TextView heading = text(
            registerMode ? "Create Your Account" : "Welcome Back",
            25, WHITE, true
        );
        heading.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams headingParams =
            new LinearLayout.LayoutParams(-1, dp(48));
        headingParams.topMargin = dp(18);
        layout.addView(heading, headingParams);

        TextView subtitle = text(
            registerMode
                ? "Register to access your personal cloud"
                : "Sign in to your personal cloud platform",
            13, MUTED, false
        );
        subtitle.setGravity(Gravity.CENTER);
        layout.addView(subtitle);

        authStatus = text(message, 12, CYAN, false);
        authStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams =
            new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(18);
        layout.addView(authStatus, statusParams);

        authEmail = createAuthInput(
            "Email address",
            InputType.TYPE_CLASS_TEXT |
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        );
        addAuthField(layout, authEmail);

        authPassword = createAuthInput(
            "Password",
            InputType.TYPE_CLASS_TEXT |
            InputType.TYPE_TEXT_VARIATION_PASSWORD
        );
        addAuthField(layout, authPassword);

        authUsername = null;
        authDisplayName = null;

        if (registerMode) {
            authUsername = createAuthInput(
                "Username (optional)",
                InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_NORMAL
            );
            addAuthField(layout, authUsername);

            authDisplayName = createAuthInput(
                "Display name (optional)",
                InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PERSON_NAME
            );
            addAuthField(layout, authDisplayName);
        }

        authButton = new Button(this);
        authButton.setText(registerMode ? "CREATE ACCOUNT" : "SIGN IN");
        authButton.setTextColor(Color.rgb(5, 28, 42));
        authButton.setAllCaps(false);
        authButton.setTextSize(14);
        authButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        authButton.setBackground(glassBackground(CYAN, CYAN));

        LinearLayout.LayoutParams actionParams =
            new LinearLayout.LayoutParams(-1, dp(52));
        actionParams.topMargin = dp(22);
        layout.addView(authButton, actionParams);

        boolean checking = message.startsWith("Checking saved session");
        authButton.setEnabled(!checking);
        authButton.setOnClickListener(v -> performAuth(registerMode));

        Button switchButton = new Button(this);
        switchButton.setText(
            registerMode
                ? "Already have an account? Sign in"
                : "New here? Create an account"
        );
        switchButton.setTextColor(CYAN);
        switchButton.setAllCaps(false);
        switchButton.setTextSize(13);
        switchButton.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout.LayoutParams switchParams =
            new LinearLayout.LayoutParams(-1, dp(50));
        switchParams.topMargin = dp(8);
        layout.addView(switchButton, switchParams);

        switchButton.setEnabled(!checking);
        switchButton.setOnClickListener(v ->
            showAuthScreen(!registerMode, "")
        );

        addServerControlButtons(layout, true);
        checkServer(false);

        TextView footer = text(
            "SECURE ACCESS • HIRA BHAI CLOUD OS",
            10, MUTED, true
        );
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerParams =
            new LinearLayout.LayoutParams(-1, dp(45));
        footerParams.topMargin = dp(25);
        layout.addView(footer, footerParams);
    }

    private void performAuth(boolean registerMode) {
        String email = authEmail.getText().toString().trim();
        String password = authPassword.getText().toString();
        String username = authUsername == null
            ? "" : authUsername.getText().toString().trim();
        String displayName = authDisplayName == null
            ? "" : authDisplayName.getText().toString().trim();

        if (email.isEmpty() || !email.contains("@")) {
            authStatus.setText("Please enter a valid email address.");
            return;
        }

        if (password.isEmpty()) {
            authStatus.setText("Please enter your password.");
            return;
        }

        if (registerMode &&
            password.getBytes(StandardCharsets.UTF_8).length < 12) {
            authStatus.setText(
                "Registration password must be at least 12 bytes."
            );
            return;
        }

        authButton.setEnabled(false);
        authStatus.setText("Connecting securely to Hira Bhai Cloud...");

        new Thread(() -> {
            try {
                CloudAuthClient.AuthResult result;

                if (registerMode) {
                    result = CloudAuthClient.register(
                        email, password, username, displayName
                    );
                } else {
                    result = CloudAuthClient.login(email, password);
                }

                runOnUiThread(() -> {
                    Toast.makeText(
                        this,
                        "Welcome to Hira Bhai Cloud",
                        Toast.LENGTH_LONG
                    ).show();
                    buildDashboard();
                    checkServer();
                });

            } catch (CloudAuthClient.AuthException e) {
                String error = e.getMessage();

                if ("INVALID_CREDENTIALS".equals(error)) {
                    error = "Incorrect email or password.";
                } else if ("ACCOUNT_ALREADY_EXISTS".equals(error)) {
                    error = "An account with this email already exists.";
                } else if ("PASSWORD_POLICY".equals(error)) {
                    error = "Password must contain at least 12 bytes.";
                } else if ("INVALID_EMAIL".equals(error)) {
                    error = "Please check your email address.";
                } else if ("INVALID_USERNAME".equals(error)) {
                    error = "Username must be 3-24 letters, numbers or underscores.";
                } else if ("ACCOUNT_NOT_ACTIVE".equals(error)) {
                    error = "This account is not active.";
                } else if (e.httpStatus == 429) {
                    error = "Too many attempts. Please try again later.";
                }

                final String message = error;
                runOnUiThread(() -> {
                    authStatus.setText(message);
                    authButton.setEnabled(true);
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    authStatus.setText(
                        "Connection failed. Check that the local cloud server is running."
                    );
                    authButton.setEnabled(true);
                });
            }
        }).start();
    }

    private void performLogout() {
        new Thread(() -> {
            try {
                CloudAuthClient.logout();
            } catch (Exception ignored) {
                // Local token is cleared by CloudAuthClient.logout().
            }

            runOnUiThread(() -> {
                Toast.makeText(
                    this, "Signed out successfully", Toast.LENGTH_SHORT
                ).show();
                showAuthScreen(false, "You have signed out.");
            });
        }).start();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable glassBackground(int color, int stroke) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(22));
        shape.setStroke(dp(1), stroke);
        return shape;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void buildDashboard() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        root = vertical();
        root.setPadding(dp(20), dp(22), dp(20), dp(32));
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets bars = insets.getInsets(
                android.view.WindowInsets.Type.systemBars()
            );
            scroll.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.hira_bhai_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("Hira Bhai Logo");

        LinearLayout.LayoutParams logoParams =
                new LinearLayout.LayoutParams(dp(64), dp(64));
        logoParams.rightMargin = dp(14);
        brandRow.addView(logo, logoParams);

        TextView brand = text("HIRA BHAI", 18, CYAN, true);
        brandRow.addView(brand);
        root.addView(brandRow);

        TextView heading = text("Cloud OS Control Center", 27, WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(8);
        root.addView(heading, hp);

        TextView subtitle = text("Your personal cloud management platform", 13, MUTED, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(5);
        root.addView(subtitle, sp);
        Button logoutButton = new Button(this);
        logoutButton.setText("SIGN OUT");
        logoutButton.setTextColor(CYAN);
        logoutButton.setAllCaps(false);
        logoutButton.setTextSize(12);
        logoutButton.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams logoutParams =
            new LinearLayout.LayoutParams(-1, dp(42));
        logoutParams.topMargin = dp(8);
        root.addView(logoutButton, logoutParams);
        logoutButton.setOnClickListener(v -> performLogout());


        addSectionTitle("OVERVIEW");

        LinearLayout serverCard = vertical();
        serverCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        serverCard.setBackground(glassBackground(Color.rgb(24, 53, 76), 0x8838D9F5));

        TextView serverTitle = text("LOCAL SERVER", 13, CYAN, true);
        serverCard.addView(serverTitle);

        serverStatus = text("Checking server connection...", 17, WHITE, true);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(12);
        serverCard.addView(serverStatus, statusParams);

        TextView serverAddress = text("127.0.0.1 : 8787", 13, MUTED, false);
        LinearLayout.LayoutParams addressParams = new LinearLayout.LayoutParams(-1, -2);
        addressParams.topMargin = dp(5);
        serverCard.addView(serverAddress, addressParams);

        addServerControlButtons(serverCard, false);

        refreshButton = new Button(this);
        refreshButton.setText("REFRESH SERVER STATUS");
        refreshButton.setTextColor(Color.rgb(5, 28, 42));
        refreshButton.setAllCaps(false);
        refreshButton.setTextSize(13);
        refreshButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        refreshButton.setBackground(glassBackground(CYAN, CYAN));
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(48));
        buttonParams.topMargin = dp(16);
        serverCard.addView(refreshButton, buttonParams);
        refreshButton.setOnClickListener(v -> checkServer());

        addCard(serverCard);

        addMonitoringDashboard();
        addSectionTitle("CLOUD MODULES");

        addModule("01", "Server Control", "Monitor your local server and connection", "ACTIVE", GREEN);
        addModule("02", "Database & API", "Database tools and API management", "COMING SOON", CYAN);
        addModule("03", "Users & Security", "Access control and security management", "COMING SOON", CYAN);
        addModule("04", "Storage & Backup", "Media storage and backup management", "COMING SOON", CYAN);
        addModule("05", "Activity Logs", "Review server and system activity", "COMING SOON", CYAN);
        addModule("06", "Analytics", "Cloud usage and performance insights", "COMING SOON", CYAN);
        addModule("07", "Settings & Updates", "Application configuration and updates", "COMING SOON", CYAN);
        addModule("08", "Developer Center", "Tools for future cloud expansion", "COMING SOON", CYAN);

        TextView footer = text("HIRA BHAI CLOUD OS  •  VERSION 1.0", 11, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(55));
        fp.topMargin = dp(18);
        root.addView(footer, fp);
    }

    private void addSectionTitle(String title) {
        TextView label = text(title, 12, CYAN, true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(42));
        params.topMargin = dp(16);
        root.addView(label, params);
    }

    private void addCard(View view) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(10);
        root.addView(view, params);
    }

    private void addModule(String number, String title, String description,
                           String status, int statusColor) {
        LinearLayout card = vertical();
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(glassBackground(Color.rgb(20, 43, 66), 0x665B8AA5));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView index = text(number, 13, CYAN, true);
        top.addView(index, new LinearLayout.LayoutParams(dp(38), -2));

        TextView name = text(title, 17, WHITE, true);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1));

        TextView badge = text(status, 10, statusColor, true);
        badge.setGravity(Gravity.CENTER);
        top.addView(badge);

        card.addView(top);

        TextView detail = text(description, 12, MUTED, false);
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(-1, -2);
        detailParams.topMargin = dp(9);
        card.addView(detail, detailParams);

        if (!status.equals("ACTIVE")) {
            TextView coming = text("Feature is not implemented yet", 11, statusColor, false);
            LinearLayout.LayoutParams comingParams = new LinearLayout.LayoutParams(-1, -2);
            comingParams.topMargin = dp(8);
            card.addView(coming, comingParams);
        }

        addCard(card);
    }

    private void addMonitoringDashboard() {
        addSectionTitle("LIVE MONITORING");
        LinearLayout card = vertical();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(glassBackground(Color.rgb(24, 53, 76), 0x8838D9F5));
        TextView status = text("Connecting to monitoring...", 15, CYAN, true);
        TextView details = text("Waiting for server metrics", 13, WHITE, false);
        card.addView(status);
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(-1, -2);
        dp1.topMargin = dp(12);
        card.addView(details, dp1);
        Button refresh = new Button(this);
        refresh.setText("REFRESH MONITORING");
        refresh.setAllCaps(false);
        refresh.setTextColor(Color.rgb(5, 28, 42));
        refresh.setBackground(glassBackground(CYAN, CYAN));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(46));
        bp.topMargin = dp(14);
        card.addView(refresh, bp);
        refresh.setOnClickListener(v -> refreshMonitoring(status, details));
        addCard(card);
        refreshMonitoring(status, details);
    }

    private void refreshMonitoring(TextView status, TextView details) {
        status.setText("Refreshing monitoring data...");
        new Thread(() -> {
            try {
                JSONObject data = CloudAuthClient.getMonitoring();
                JSONObject users = data.optJSONObject("users");
                JSONObject storage = data.optJSONObject("storage");
                JSONObject memory = data.optJSONObject("memory");
                long ram = memory == null ? 0 : memory.optLong("rss");
                long used = storage == null ? 0 : storage.optLong("usedBytes");
                long free = storage == null ? 0 : storage.optLong("freeBytes");
                JSONObject activity = data.optJSONObject("activity");
                StringBuilder report = new StringBuilder();
                report.append("Uptime: ").append(data.optLong("uptimeSeconds")).append(" seconds\n");
                report.append("Users: ").append(users == null ? 0 : users.optInt("total"))
                      .append(" | Active: ").append(users == null ? 0 : users.optInt("active")).append("\n");
                report.append("Active Sessions: ").append(data.optInt("activeSessions")).append("\n");
                report.append("RAM Used: ").append(ram / 1048576).append(" MB\n");
                report.append("Media Files: ").append(storage == null ? 0 : storage.optInt("files")).append("\n");
                report.append("Media Storage: ").append(used / 1048576).append(" MB\n");
                report.append("Disk Free: ").append(free / 1073741824).append(" GB\n\n");
                report.append("API REQUESTS: ").append(activity == null ? 0 : activity.optInt("total")).append("\n");
                report.append("Successful: ").append(activity == null ? 0 : activity.optInt("success")).append("\n");
                report.append("Client Errors: ").append(activity == null ? 0 : activity.optInt("clientErrors")).append("\n");
                report.append("Server Errors: ").append(activity == null ? 0 : activity.optInt("serverErrors")).append("\n");
                report.append("Uploads: ").append(activity == null ? 0 : activity.optInt("uploads")).append("\n");
                report.append("Video Streams: ").append(activity == null ? 0 : activity.optInt("streams")).append("\n");
                report.append("Streamed Data: ").append(activity == null ? 0 : activity.optLong("streamedBytes") / 1048576).append(" MB\n\n");
                if (activity != null) {
                    org.json.JSONArray routes = activity.optJSONArray("topRoutes");
                    report.append("TOP API ROUTES\n");
                    if (routes != null) for (int i=0; i<routes.length(); i++) {
                        JSONObject item=routes.optJSONObject(i);
                        if(item!=null) report.append(item.optString("route")).append(" : ").append(item.optInt("count")).append("\n");
                    }
                    org.json.JSONArray logs = activity.optJSONArray("recentLogs");
                    report.append("\nRECENT ACTIVITY LOGS\n");
                    if (logs != null) for (int i=Math.max(0,logs.length()-8); i<logs.length(); i++) {
                        JSONObject item=logs.optJSONObject(i);
                        if(item!=null) report.append(item.optString("time")).append(" | ")
                            .append(item.optString("method")).append(" ")
                            .append(item.optString("route")).append(" | HTTP ")
                            .append(item.optInt("status")).append("\n");
                    }
                }
                runOnUiThread(() -> {
                    status.setText("LIVE • ADMIN MONITORING");
                    details.setText(report.toString());
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("MONITORING UNAVAILABLE");
                    details.setText("Admin access required or server unavailable. Please retry.");
                });
            }
        }).start();
    }

    private void addServerControlButtons(LinearLayout parent, boolean loginScreen) {
        TextView title = text("EMERGENCY SERVER CONTROL", 12, CYAN, true);
        LinearLayout.LayoutParams titleParams =
            new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(16);
        parent.addView(title, titleParams);

        if (loginScreen) {
            loginServerStatus = text("Checking local server...", 14, WHITE, true);
            LinearLayout.LayoutParams statusParams =
                new LinearLayout.LayoutParams(-1, -2);
            statusParams.topMargin = dp(7);
            parent.addView(loginServerStatus, statusParams);
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button onButton = new Button(this);
        onButton.setText("SERVER ON");
        onButton.setAllCaps(false);
        onButton.setTextColor(Color.rgb(5, 28, 42));
        onButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        onButton.setBackground(glassBackground(GREEN, GREEN));

        Button offButton = new Button(this);
        offButton.setText("SERVER OFF");
        offButton.setAllCaps(false);
        offButton.setTextColor(WHITE);
        offButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        offButton.setBackground(glassBackground(0xFFB94B55, 0xFFFF8585));

        LinearLayout.LayoutParams buttonParams =
            new LinearLayout.LayoutParams(0, dp(48), 1);
        buttonParams.topMargin = dp(10);
        buttonParams.rightMargin = dp(5);
        row.addView(onButton, buttonParams);

        LinearLayout.LayoutParams offParams =
            new LinearLayout.LayoutParams(0, dp(48), 1);
        offParams.topMargin = dp(10);
        offParams.leftMargin = dp(5);
        row.addView(offButton, offParams);

        parent.addView(row);

        onButton.setOnClickListener(v -> requestTermuxServerCommand("start"));
        offButton.setOnClickListener(v -> requestTermuxServerCommand("stop"));
    }

    private void requestTermuxServerCommand(String action) {
        if (serverCommandInProgress) {
            Toast.makeText(
                this,
                "Please wait. Previous server command is being processed.",
                Toast.LENGTH_SHORT
            ).show();
            return;
        }

        serverCommandInProgress = true;

        Intent intent = new Intent();
        intent.setClassName(
            "com.termux",
            "com.termux.app.RunCommandService"
        );
        intent.setAction("com.termux.RUN_COMMAND");

        intent.putExtra(
            "com.termux.RUN_COMMAND_PATH",
            "/data/data/com.termux/files/usr/bin/bash"
        );
        intent.putExtra(
            "com.termux.RUN_COMMAND_ARGUMENTS",
            new String[]{
                "/data/data/com.termux/files/home/hira-cloud/server-control.sh",
                action
            }
        );
        intent.putExtra(
            "com.termux.RUN_COMMAND_WORKDIR",
            "/data/data/com.termux/files/home/hira-cloud"
        );
        intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);

        try {
            startService(intent);


            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                checkServer(false);
                serverCommandInProgress = false;
            }, 7000);

        } catch (SecurityException e) {
            serverCommandInProgress = false;
        } catch (Exception e) {
            serverCommandInProgress = false;
        }
    }

    private void checkServer() {
        checkServer(true);
    }

    private void checkServer(boolean showToast) {
        if (refreshButton != null) refreshButton.setEnabled(false);
        if (serverStatus != null) serverStatus.setText("Checking local server...");

        new Thread(() -> {
            String result;
            HttpURLConnection connection = null;
            try {
                URL url = new URL("http://127.0.0.1:8787/health");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(3000);
                connection.setReadTimeout(3000);

                if (connection.getResponseCode() == 200) {
                    result = "●  Local server is ONLINE";
                } else {
                    result = "●  Server responded with an error";
                }
            } catch (Exception e) {
                result = "●  Local server is OFFLINE";
            } finally {
                if (connection != null) connection.disconnect();
            }

            final String message = result;
            runOnUiThread(() -> {
                if (serverStatus != null) {
                    serverStatus.setText(message);
                    serverStatus.setTextColor(message.contains("ONLINE") ? GREEN : 0xFFFF9B8E);
                }
                if (loginServerStatus != null) {
                    loginServerStatus.setText(message);
                    loginServerStatus.setTextColor(message.contains("ONLINE") ? GREEN : 0xFFFF9B8E);
                }
                if (refreshButton != null) refreshButton.setEnabled(true);
                if (showToast) {
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }
}
