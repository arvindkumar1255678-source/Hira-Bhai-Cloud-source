package com.hirabhai.cloud;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class CloudAuthClient {
    private static final String BASE_URL = "http://127.0.0.1:8787";

    private CloudAuthClient() {}

    public static final class User {
        public final String id;
        public final String email;
        public final String username;
        public final String displayName;
        public final String role;
        public final String status;
        public final String createdAt;

        User(JSONObject json) {
            id = json.optString("id", "");
            email = json.optString("email", "");
            username = json.optString("username", "");
            displayName = json.optString("displayName", "");
            role = json.optString("role", "");
            status = json.optString("status", "");
            createdAt = json.optString("createdAt", "");
        }
    }

    public static final class AuthResult {
        public final User user;
        public final String expiresAt;

        AuthResult(User user, String expiresAt) {
            this.user = user;
            this.expiresAt = expiresAt;
        }
    }

    public static final class AuthException extends Exception {
        public final int httpStatus;

        AuthException(int status, String message) {
            super(message);
            httpStatus = status;
        }
    }

    private static final class HttpResult {
        final int status;
        final String body;

        HttpResult(int status, String body) {
            this.status = status;
            this.body = body;
        }
    }

    private static String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";

        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }

    private static HttpResult request(
            String method, String path, JSONObject body, String token)
            throws Exception {

        HttpURLConnection connection = null;

        try {
            URL url = new URL(BASE_URL + path);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(15000);
            connection.setRequestProperty("Accept", "application/json");

            if (body != null) {
                connection.setDoOutput(true);
                connection.setRequestProperty(
                        "Content-Type", "application/json; charset=UTF-8");

                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(bytes);
                }
            }

            if (token != null) {
                connection.setRequestProperty(
                        "Authorization", "Bearer " + token);
            }

            int status = connection.getResponseCode();
            InputStream stream = status >= 400
                    ? connection.getErrorStream()
                    : connection.getInputStream();

            return new HttpResult(status, readStream(stream));
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static JSONObject parse(String value) throws Exception {
        if (value == null || value.trim().isEmpty()) {
            return new JSONObject();
        }
        return new JSONObject(value);
    }

    private static void checkSuccess(HttpResult response) throws Exception {
        if (response.status >= 200 && response.status < 300) return;

        String message = "Cloud authentication failed";
        try {
            message = parse(response.body).optString("error", message);
        } catch (Exception ignored) {}

        throw new AuthException(response.status, message);
    }

    private static AuthResult saveAuthResponse(HttpResult response)
            throws Exception {
        checkSuccess(response);

        JSONObject json = parse(response.body);
        String token = json.optString("token", "");

        if (!token.matches("[A-Za-z0-9_-]{43}")) {
            throw new IllegalStateException("Server returned an invalid token");
        }

        JSONObject userJson = json.optJSONObject("user");
        if (userJson == null || userJson.optString("id", "").isEmpty()) {
            throw new IllegalStateException("Server returned invalid user data");
        }

        User user = new User(userJson);
        Vault.putToken(token);

        return new AuthResult(user, json.optString("expiresAt", ""));
    }

    public static AuthResult register(
            String email, String password,
            String username, String displayName) throws Exception {

        JSONObject body = new JSONObject();
        body.put("email", email);
        body.put("password", password);

        if (username != null && !username.trim().isEmpty()) {
            body.put("username", username.trim());
        }
        if (displayName != null && !displayName.trim().isEmpty()) {
            body.put("displayName", displayName.trim());
        }

        return saveAuthResponse(request(
                "POST", "/api/auth/register", body, null));
    }

    public static AuthResult login(String email, String password)
            throws Exception {
        JSONObject body = new JSONObject();
        body.put("email", email);
        body.put("password", password);

        return saveAuthResponse(request(
                "POST", "/api/auth/login", body, null));
    }

    public static User verifySession() throws Exception {
        String token = Vault.getToken();
        if (token == null) return null;

        HttpResult response = request(
                "GET", "/api/auth/me", null, token);

        if (response.status == 401) {
            Vault.clearToken();
            return null;
        }

        checkSuccess(response);

        JSONObject userJson = parse(response.body).optJSONObject("user");
        if (userJson == null || userJson.optString("id", "").isEmpty()) {
            throw new IllegalStateException("Invalid session response");
        }

        return new User(userJson);
    }

    public static JSONObject getMonitoring() throws Exception {
        String token = Vault.getToken();
        if (token == null) throw new IllegalStateException("Login required");
        HttpResult response = request("GET", "/admin/monitoring", null, token);
        checkSuccess(response);
        return parse(response.body);
    }

    public static void logout() throws Exception {
        String token = Vault.getToken();

        try {
            if (token != null) {
                HttpResult response = request(
                        "POST", "/api/auth/logout", null, token);

                if (response.status != 401) {
                    checkSuccess(response);
                }
            }
        } finally {
            Vault.clearToken();
        }
    }

    public static boolean hasSession() {
        return Vault.getToken() != null;
    }
}
